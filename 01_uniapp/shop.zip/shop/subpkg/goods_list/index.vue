<template>
  <view>
    <text>list</text>
  </view>
</template>

<script>
  export default {
    data() {
      return {
        
      };
    },
    onLoad(v) {
        console.log(v)
    }
  }
</script>

<style lang="scss">

</style>
